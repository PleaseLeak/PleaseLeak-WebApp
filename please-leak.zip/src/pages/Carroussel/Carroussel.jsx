import React from "react";
import { useParams } from "react-router-dom";
import PageContainer from "../../components/layout/PageContainer";
import { appContext } from "../../context/AppContext";
import { Image } from "@chakra-ui/react";
import { downloadFile, parseToDirectusLink } from "../../utils/tools";
import "./Carroussel.css";
import {
  BsFillArrowLeftCircleFill,
  BsFillArrowRightCircleFill,
} from "react-icons/bs";
import { useRef, useEffect, useState, useContext } from "react";
import ButtonSimple from "../../components/Button/ButtonSimple";

const Carroussel = () => {
  const params = useParams();

  const {
    AssPicturesFetched,
    BoobsPicturesFetched,
    PussyPicturesFetched,
    settings,
  } = useContext(appContext);
  const allPictures =
    params.type === "ass"
      ? AssPicturesFetched.data?.data
      : params.type === "pussy"
      ? PussyPicturesFetched.data?.data
      : params.type === "boobs"
      ? BoobsPicturesFetched.data?.data
      : [];

  const [selectedPicture, setSelectedPicture] = useState(JSON.parse(params.id));

  const qualityPicture =
    settings.picturesQuality === "low"
      ? 150
      : settings.picturesQuality === "medium"
      ? 900
      : 1;

  const imageRef = useRef();

  useEffect(() => {
    const cachingArray =
      params.type === "ass"
        ? AssPicturesFetched
        : params.type === "pussy"
        ? PussyPicturesFetched
        : params.type === "boobs"
        ? BoobsPicturesFetched
        : [];

    if (cachingArray.isSuccess) {
      if (selectedPicture != allPictures.length - 1) {
        document.createElement("IMG").src = parseToDirectusLink(
          allPictures[selectedPicture + 1].image,
          qualityPicture
        );
      }
      if (cachingArray >= 1) {
        document.createElement("IMG").src = parseToDirectusLink(
          allPictures[selectedPicture - 1].image,
          qualityPicture
        );
      }
    }
  }, [selectedPicture]);

  return (
    <PageContainer flexDirection={"column"} addClass={"carroussel"}>
      {allPictures && (
        <Image
          mb={5}
          ref={imageRef}
          className="carroussel-image"
          minHeight={"65vh"}
          minWidth={200}
          maxWidth={"98vw"}
          maxHeight={"85vh"}
          objectFit={"cover"}
          src={parseToDirectusLink(
            allPictures[selectedPicture] && allPictures[selectedPicture].image,
            qualityPicture
          )}
          zIndex={0}
        />
      )}
      {params.type === "wallpaper" && (
        <ButtonSimple
          onClick={() => {
            downloadFile(
              parseToDirectusLink(
                params.type === "wallpaper"
                  ? allPictures[selectedPicture].wallpaper
                  : allPictures[selectedPicture].image,
                0
              )
            );
          }}
          mt={5}
        >
          Download
        </ButtonSimple>
      )}
      <div
        className="control"
        style={{
          zIndex: 0,
        }}
      >
        <div
          className="left-button"
          onClick={() => {
            imageRef.current.classList.remove("carroussel-image");
            imageRef.current.classList.remove("carroussel-image-left");

            void imageRef.current.offsetWidth;
            imageRef.current.className = "carroussel-image-left";

            if (selectedPicture > 0) {
              setSelectedPicture((current) => current - 1);
            }
          }}
        >
          <BsFillArrowLeftCircleFill />
        </div>
        <div
          className="right-button"
          onClick={() => {
            imageRef.current.classList.remove("carroussel-image-left");
            imageRef.current.classList.remove("carroussel-image");

            void imageRef.current.offsetWidth;
            imageRef.current.className = "carroussel-image";

            if (selectedPicture < allPictures.length - 1) {
              setSelectedPicture((current) => current + 1);
            }
          }}
        >
          <BsFillArrowRightCircleFill />
        </div>
      </div>
    </PageContainer>
  );
};

export default Carroussel;
