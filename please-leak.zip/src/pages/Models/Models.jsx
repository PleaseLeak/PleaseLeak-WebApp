import {
  Container,
  Flex,
  Button,
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
  IconButton,
  Radio,
  RadioGroup,
  Stack,
  Heading,
  Divider,
  Tooltip,
} from "@chakra-ui/react";
import { useContext } from "react";
import { appContext } from "../../context/AppContext";
import { useState } from "react";
import { FormControl, Input } from "@chakra-ui/react";
import { useTransition } from "react";
import ListeModels from "./ListeModels";
import { useEffect } from "react";
import PageContainer from "../../components/layout/PageContainer";
import { useParams } from "react-router-dom";
import { useRef } from "react";
import { FaFilter } from "react-icons/fa";
import { NavLink } from "react-router-dom";

export default function Models() {
  const params = useParams();
  const { ModelsFetched } = useContext(appContext);
  const [numberLoaded, setNumberLoaded] = useState(4);
  const [search, setSearch] = useState("");
  const [models, setModels] = useState(ModelsFetched.data?.data || []);
  useEffect(() => {
    setModels(ModelsFetched.data?.data || []);
  }, [ModelsFetched]);
  const filteredModels = ModelsFetched.data?.data.filter((model) => {
    return model.name.toLowerCase().includes(search.toLowerCase());
  });

  // transition to the search bar
  // eslint-disable-next-line no-unused-vars
  const [isLoading, startTransition] = useTransition();

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setNumberLoaded(3);
    startTransition(() => {
      setModels(filteredModels);
    });
  };

  useEffect(() => {
    if (params.search) {
      const filteredModels = ModelsFetched.data?.data.filter((model) => {
        return model.name.toLowerCase().includes(params.search.toLowerCase());
      });
      if (filteredModels) {
        setModels(filteredModels);
      }
      setSearch(params.search);
    } else {
      setModels(ModelsFetched.data?.data || []);
    }
  }, [ModelsFetched]);

  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = useRef();
  const [isLastUpdate, setIsLastUpdate] = useState(false);

  const updateFilter = () => {
    startTransition(() => {
      if (isLastUpdate) {
        setModels(
          ModelsFetched.data?.data
            .filter((model) => {
              return model.name.toLowerCase().includes(search.toLowerCase());
            })
            .reverse()
        );
      } else {
        setModels(
          ModelsFetched.data?.data.filter((model) => {
            return model.name.toLowerCase().includes(search.toLowerCase());
          })
        );
      }
    });
    onClose();
  };
  return (
    <>
      <Drawer
        isOpen={isOpen}
        placement="right"
        onClose={onClose}
        finalFocusRef={btnRef}
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Apply Filter</DrawerHeader>

          <DrawerBody>
            <Heading mb={2} size={"md"}>
              Search by name
            </Heading>
            <Input
              onChange={handleSearch}
              value={search}
              type="text"
              placeholder="Models name"
            />
            <Divider w={"auto"} m={3} />
            <Heading mb={2} size={"md"}>
              Order by
            </Heading>
            <RadioGroup
              onChange={(e) => {
                console.log(JSON.parse(e));
                setIsLastUpdate(JSON.parse(e));
              }}
              value={JSON.stringify(isLastUpdate)}
            >
              <Stack direction="row">
                <Radio value={"true"}>Last upload</Radio>
                <Radio value={"false"}>First upload</Radio>
              </Stack>
            </RadioGroup>
          </DrawerBody>

          <DrawerFooter>
            <Button colorScheme="purple" mr={3} onClick={updateFilter}>
              Save
            </Button>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>

      <PageContainer flexDirection={"column"}>
        <Heading mt={2}>Write without space</Heading>
        <Container
          mb={5}
          mt={5}
          spacing={4}
          as={Container}
          maxW={"3xl"}
          textAlign={"center"}
          display={"flex"}
          gap={5}
        >
          <FormControl>
            <Input
              onChange={handleSearch}
              value={search}
              type="text"
              placeholder="Search Models"
            />
          </FormControl>
          <Tooltip
            hasArrow
            label="Models Filter option"
            bg="gray.300"
            color="black"
          >
            <IconButton
              bg={"purple"}
              color={"white"}
              rounded={"md"}
              _hover={{
                transform: "translateY(-2px)",
                boxShadow: "lg",
              }}
              icon={<FaFilter />}
              onClick={onOpen}
            ></IconButton>
          </Tooltip>
        </Container>
        {models.length !== 0 ? (
          <ListeModels models={models} numberLoaded={numberLoaded} />
        ) : (
          <NavLink to="/help/girl">
            <Button my={5} colorScheme="purple">
              Request new girl
            </Button>
          </NavLink>
        )}
        <Flex my={5} gap={5} justify="center">
          {models.length !== 0 && (
            <Button
              onClick={() => setNumberLoaded((current) => current + 4)}
              colorScheme="purple"
            >
              Load more
            </Button>
          )}
        </Flex>
      </PageContainer>
    </>
  );
}
