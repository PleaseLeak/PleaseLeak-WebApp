/* eslint-disable react/prop-types */
import { useContext } from "react";
import ModelsCard from "../../components/Card/ModelsCard";
import { Container, Flex } from "@chakra-ui/react";
import { userContext } from "../../context/userContext";

const ListeModels = ({ models, numberLoaded }) => {
  const { userLikes } = useContext(userContext);

  return (
    <Container maxW={"100%"}>
      <Flex flexWrap="wrap" w={"full"} gridGap={6} justify="center">
        {models.slice(0, numberLoaded).map((model) => {
          return (
            <ModelsCard
              key={model.id}
              name={model.name}
              profilePicture={model.preview}
              preview={model.sub_preview_1}
              link={model.link}
              isLiked={userLikes?.includes(model.id)}
              modelId={model.id}
            />
          );
        })}
      </Flex>
    </Container>
  );
};

export default ListeModels;
