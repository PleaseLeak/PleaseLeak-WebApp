/* eslint-disable react/prop-types */
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  Stack,
  Button,
  Avatar,
  Box,
  Input,
} from "@chakra-ui/react";
import { useContext } from "react";
import { useRef } from "react";
import { appContext } from "../../../../context/AppContext";
import { useState } from "react";
import { parseToDirectusLink } from "../../../../utils/tools";
import ButtonSimple from "../../../../components/Button/ButtonSimple";
import { useEffect } from "react";

export default function ModelsDrawer({ isOpen, onClose, setProfilUrl }) {
  const firstField = useRef();
  const { ModelsFetched } = useContext(appContext);
  const [numberLoaded, setNumberLoaded] = useState(12);
  const [modelsListeFiltered, setModelsListeFiltered] = useState([]);
  useEffect(() => {
    if (ModelsFetched.data?.data) {
      setModelsListeFiltered(ModelsFetched.data?.data);
    }
  }, [ModelsFetched]);
  const [selectedModels, setSelectedModels] = useState(null);
  const handleModelClick = (modelId) => {
    setSelectedModels(modelId);
  };
  const handleSearch = (e) => {
    const value = e.target.value;
    const filtered = ModelsFetched.data?.data.filter((el) => {
      return el.name.toLowerCase().includes(value.toLowerCase());
    });
    setModelsListeFiltered(filtered);
  };

  return (
    <>
      <Drawer
        isOpen={isOpen}
        placement="right"
        initialFocusRef={firstField}
        onClose={onClose}
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader borderBottomWidth="1px">Select Models</DrawerHeader>

          <DrawerBody overflow={"auto"}>
            <Stack
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
              spacing="24px"
            >
              <Input
                onChange={handleSearch}
                ref={firstField}
                placeholder="Models"
                autoFocus={false}
              />

              <Box
                w={"full"}
                maxH={"55vh"}
                overflow={"auto"}
                display={"flex"}
                flexDirection={"column"}
                alignItems={"center"}
                gap={5}
              >
                {
                  //liste of models with line breaking
                  modelsListeFiltered.slice(0, numberLoaded).map((model) => {
                    let style = {
                      cursor: "pointer",
                      border: "2px solid purple",
                      boxShadow: "lg",
                      transform: "scale(1.2)",
                      transition: "all 0.2s ease-in-out",
                      filter: "brightness(0.8)",
                      _after: {
                        content: '"✔"',
                        position: "absolute",
                        top: "0",
                        left: "0",
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        fontSize: "2rem",
                        color: "purple",
                      },
                    };

                    return (
                      <Avatar
                        onClick={() => {
                          handleModelClick(model.id);
                        }}
                        key={model.id}
                        name={model.name}
                        src={parseToDirectusLink(model.preview)}
                        size={"2xl"}
                        style={model.id === selectedModels ? style : null}
                        _hover={{
                          cursor: "pointer",
                          border: "2px solid purple",
                          boxShadow: "lg",
                          transform: "scale(1.1)",
                          transition: "all 0.2s ease-in-out",
                          filter: "brightness(0.8)",
                          _after: {
                            content: '"✔"',
                            position: "absolute",
                            top: "0",
                            left: "0",
                            width: "100%",
                            height: "100%",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            fontSize: "2rem",
                            color: "purple",
                          },
                        }}
                      />
                    );
                  })
                }
              </Box>

              <ButtonSimple
                onClick={() => {
                  setNumberLoaded((current) => current + 4);
                }}
              >
                Show More
              </ButtonSimple>
            </Stack>
          </DrawerBody>

          <DrawerFooter borderTopWidth="1px">
            <Button variant="outline" mr={3} onClick={onClose}>
              Cancel
            </Button>
            <Button
              colorScheme="blue"
              onClick={() => {
                let urlProfile = ModelsFetched.data?.data.filter((el) => {
                  return el.id === selectedModels;
                })[0].preview;
                setProfilUrl(parseToDirectusLink(urlProfile));
                onClose();
              }}
            >
              Submit
            </Button>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    </>
  );
}
