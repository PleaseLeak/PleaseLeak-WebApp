import { Heading, Button, Container } from "@chakra-ui/react";
import ListeModels from "../../Models/ListeModels";
import { useState } from "react";
import { useContext } from "react";
import { appContext } from "../../../context/AppContext";
import { userContext } from "../../../context/userContext";
import PageContainer from "../../../components/layout/PageContainer";
const Favorites = () => {
  const [numberLoaded, setNumberLoaded] = useState(4);
  const { ModelsFetched } = useContext(appContext);
  const { userLikes } = useContext(userContext);
  const modelsListe =
    ModelsFetched.data?.data.filter((el) => {
      return userLikes?.includes(el.id);
    }) || [];
  return (
    <PageContainer flexDirection={"column"}>
      <Heading mt={10}>Your Favorites</Heading>
      {modelsListe.length > 0 ? (
        <ListeModels numberLoaded={numberLoaded} models={modelsListe} />
      ) : (
        <Container
          display={"flex"}
          alignItems={"center"}
          height={500}
          mt={10}
          textAlign="center"
        >
          <Heading mt={10}>You have no favorites yet</Heading>
        </Container>
      )}
      <Button
        my={5}
        onClick={() => setNumberLoaded((current) => current + 4)}
        className="btn btn-primary"
      >
        Load More
      </Button>
    </PageContainer>
  );
};

export default Favorites;
