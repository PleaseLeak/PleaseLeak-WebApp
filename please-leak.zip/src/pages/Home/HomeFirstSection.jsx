import { useContext } from "react";
import ModelsCard from "../../components/Card/ModelsCard";
import {
  Box,
  Heading,
  Text,
  Stack,
  Container,
  useColorModeValue,
  Button,
  Tooltip,
} from "@chakra-ui/react";
import { appContext } from "../../context/AppContext";
import { userContext } from "../../context/userContext";
import { NavLink } from "react-router-dom";
export default function HomeFirstSection() {
  const { ModelsFetched } = useContext(appContext);
  const { userLikes } = useContext(userContext);
  let lastModels;
  // if mobile slice -2
  if (window.innerWidth < 768) {
    lastModels = ModelsFetched.data?.data.slice(-2);
  } else {
    lastModels = ModelsFetched.data?.data.slice(-3);
  }

  return (
    <>
      <Box borderRadius={10} bg={useColorModeValue("gray.100", "gray.700")}>
        <Container
          maxW={"full"}
          py={16}
          as={Stack}
          spacing={12}
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Stack spacing={0} align={"center"}>
            <Heading color={"purple.700"}>Latest Models Added</Heading>
            <Text>Get Amazing Mega Link</Text>
          </Stack>
          {/*liste of models with line breaking */}
          <Stack
            direction={{ base: "column", md: "row" }}
            spacing={{ base: 10, md: 4, lg: 10 }}
            style={{
              flexWrap: "wrap",
              justifyContent: "center",
            }}
          >
            {ModelsFetched.data ? (
              <>
                {lastModels.map((model) => (
                  <ModelsCard
                    key={model.id}
                    name={model.name}
                    profilePicture={model.preview}
                    preview={model.sub_preview_1}
                    link={model.link}
                    isLiked={userLikes?.includes(model.id)}
                    modelId={model.id}
                  />
                ))}
              </>
            ) : (
              "Loading..."
            )}
          </Stack>
          <NavLink to={"/models"}>
            <Tooltip
              hasArrow
              label="Go to models page"
              bg="gray.300"
              color="black"
            >
              <Button w={"160px"} colorScheme={"purple"}>
                View All Models
              </Button>
            </Tooltip>
          </NavLink>
        </Container>
      </Box>
    </>
  );
}
