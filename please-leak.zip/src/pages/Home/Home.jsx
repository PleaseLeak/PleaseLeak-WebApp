import HomeFirstSection from "./HomeFirstSection";
import HomeHero from "./HomeHero";
import { Container } from "@chakra-ui/react";
import HomeStats from "./HomeStats";

const Home = () => {
  return (
    <>
      <video
        className="hero-video"
        src="https://please-leak.com/src/main-video.mp4"
        muted
        loop
        autoPlay
      />

      <Container bg={"gray.300"} m={0} pb={10} maxW={"100vw"}>
        <HomeHero />
        <Container mt={{ base: -440, md: -600 }} mb={10} p={0} maxW={"4xl"}>
          <HomeStats />
        </Container>
        <Container p={0} maxW={"6xl"}>
          <HomeFirstSection />
        </Container>
      </Container>
    </>
  );
};

export default Home;
