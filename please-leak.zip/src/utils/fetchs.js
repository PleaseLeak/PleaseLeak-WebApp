export async function getModels() {
  let data = await fetch(
    "https://directus.please-leak.com/items/models?limit=300"
  ).then((res) => {
    // inverse le tableau
    return res.json().then((data) => {
      return data;
    });
  });
  return data;
}

export async function getAssPictures() {
  let data = await fetch(
    "https://directus.please-leak.com/items/ass_pictures?limit=300"
  ).then((res) => {
    // inverse le tableau
    return res.json().then((data) => {
      return data;
    });
  });
  return data;
}

export async function getPussyPictures() {
  let data = await fetch(
    "https://directus.please-leak.com/items/pussy_pictures?limit=300"
  ).then((res) => {
    // inverse le tableau
    return res.json().then((data) => {
      return data;
    });
  });
  return data;
}

export async function getBoobsPictures() {
  let data = await fetch(
    "https://directus.please-leak.com/items/boobs_pictures?limit=300"
  ).then((res) => {
    // inverse le tableau
    return res.json().then((data) => {
      return data;
    });
  });
  return data;
}

export async function getAllVideos() {
  let data = await fetch(
    "https://directus.please-leak.com/items/videos?limit=300"
  ).then((res) => {
    // inverse le tableau
    return res.json().then((data) => {
      return data;
    });
  });
  return data;
}
