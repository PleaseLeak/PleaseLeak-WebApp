import { createContext } from "react";
import { useQuery } from "react-query";
import {
  getAllVideos,
  getAssPictures,
  getBoobsPictures,
  getModels,
  getPussyPictures,
} from "../utils/fetchs";
import { parseToDirectusLink } from "../utils/tools";
import { useState, useEffect } from "react";
import LoaderPage from "../components/Loader/LoaderPage";
/* eslint-disable react/prop-types */
export const appContext = createContext();

const AppContextProvider = ({ children }) => {
  const [settings, setSettings] = useState(
    JSON.parse(localStorage.getItem("settings")) || {
      picturesQuality: "medium",
      bannerQuality: "high",
    }
  );

  const ModelsFetched = useQuery({
    queryKey: ["models"],
    queryFn: getModels,
  });
  const AssPicturesFetched = useQuery({
    queryKey: ["ass-pictures"],
    queryFn: getAssPictures,
  });
  const PussyPicturesFetched = useQuery({
    queryKey: ["pussy-pictures"],
    queryFn: getPussyPictures,
  });
  const BoobsPicturesFetched = useQuery({
    queryKey: ["boobs-pictures"],
    queryFn: getBoobsPictures,
  });
  const VideosFetched = useQuery({
    queryKey: ["videos"],
    queryFn: getAllVideos,
  });

  useEffect(() => {
    localStorage.setItem("settings", JSON.stringify(settings));
  }, [settings]);

  return (
    <appContext.Provider
      value={{
        ModelsFetched,
        AssPicturesFetched,
        PussyPicturesFetched,
        BoobsPicturesFetched,
        VideosFetched,
        settings,
        setSettings,
      }}
    >
      {children}
    </appContext.Provider>
  );
};

export default AppContextProvider;
